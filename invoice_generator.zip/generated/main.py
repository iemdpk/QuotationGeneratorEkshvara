from PIL import Image, ImageDraw, ImageFont
 

img = Image.open('out.png')
 

d1 = ImageDraw.Draw(img)
 

myFont = ImageFont.truetype('Roboto-Light.ttf', 35)
 
#y,x



name = input("Enter your Client Name");
number = input("Enter your Client Number");
email = input("Enter your Client Email");
address = input("Enter your Client address");

invoiceNo = input("Enter your InVoiceNumber");
date = input("Enter your Issued Date");


firstProjectDescription = input("Enter your 1 Project Description");
firstProjectquantity = input("Enter your 1 Project Quantity");
firstProjectPrice = input("Enter your 1 Project Price");

secondProjectDescription = input("Enter your 2 Project Description");
secondProjectquantity = input("Enter your 2 Project Quantity");
secondProjectPrice = input("Enter your 2 Project Price");

thirdProjectDescription = input("Enter your 3 Project Description");
thirdProjectquantity = input("Enter your 3 Project Quantity");
thirdProjectPrice = input("Enter your 3 Project Price");

fourthProjectDescription = input("Enter your 4 Project Description");
fourthProjectquantity = input("Enter your 4 Project Quantity");
fourthProjectPrice = input("Enter your 4 Project Price");

fifthProjectDescription = input("Enter your 5 Project Description");
fifthProjectquantity = input("Enter your 5 Project Quantity");
fifthProjectPrice = input("Enter your 5 Project Price");




totalAmount = input("Enter your Total Amount");
tax = input("Enter your 5 Project Tax(18%)");
amountDue = input("Enter your Amount Due");


#name
d1.text((920, 300), str(name), fill =(27,39,90,255),font=myFont)

#number
d1.text((920, 360),str(number), fill =(27,39,90,255),font=myFont)


#email
d1.text((920, 410),str(email), fill =(27,39,90,255),font=myFont)



#address
d1.text((920, 470),str(address), fill =(27,39,90,255),font=myFont)


#name
#d1.text((920, 290), "Deepak Mishra", fill =(27,39,90,255),font=myFont)
 
myFontBold = ImageFont.truetype('Roboto-Bold.ttf', 40)

#invoiceNumber
d1.text((473, 507), str(invoiceNo), fill =(27,39,90,255),font=myFontBold)

myFontLight = ImageFont.truetype('Roboto-Bold.ttf', 30)

#issued_date
d1.text((410, 585), str(date), fill =(27,39,90,255),font=myFontLight)

#=========================================================First Software===========================================================================

#software name
d1.text((220, 830), str(firstProjectDescription), fill =(27,39,90,255),font=myFont)
#software Quantity
d1.text((870, 830), str(firstProjectquantity), fill =(27,39,90,255),font=myFont)
#software price
d1.text((1070, 830), str(firstProjectPrice), fill =(27,39,90,255),font=myFont)
#total price
d1.text((1320, 830), str(firstProjectPrice), fill =(27,39,90,255),font=myFont)

#=========================================================End Software===========================================================================



#=========================================================Second Software===========================================================================

#software name
d1.text((220, 900),str(secondProjectDescription), fill =(27,39,90,255),font=myFont)
#software Quantity
d1.text((870, 900), str(secondProjectquantity), fill =(27,39,90,255),font=myFont)
#software price
d1.text((1070, 900), str(secondProjectPrice), fill =(27,39,90,255),font=myFont)
#total price
d1.text((1320, 900), str(secondProjectPrice), fill =(27,39,90,255),font=myFont)

#=========================================================End Software===========================================================================



#=========================================================Third Software===========================================================================

#software name
d1.text((220, 970), str(thirdProjectDescription), fill =(27,39,90,255),font=myFont)
#software Quantity
d1.text((870, 970), str(thirdProjectquantity), fill =(27,39,90,255),font=myFont)
#software price
d1.text((1070, 970), str(thirdProjectPrice), fill =(27,39,90,255),font=myFont)
#total price
d1.text((1320, 970), str(thirdProjectPrice) , fill =(27,39,90,255),font=myFont)

#=========================================================End Software===========================================================================



#=========================================================fourth Software===========================================================================

#software name
d1.text((220, 1050), str(fourthProjectDescription), fill =(27,39,90,255),font=myFont)
#software Quantity
d1.text((870, 1050), str(fourthProjectquantity), fill =(27,39,90,255),font=myFont)
#software price
d1.text((1070, 1050), str(fourthProjectPrice), fill =(27,39,90,255),font=myFont)
#total price
d1.text((1320, 1050), str(fourthProjectPrice), fill =(27,39,90,255),font=myFont)

#=========================================================End Software===========================================================================



#=========================================================fifth Software===========================================================================

#software name
d1.text((220, 1120), str(fifthProjectDescription), fill =(27,39,90,255),font=myFont)
#software Quantity
d1.text((870, 1120), str(fifthProjectquantity), fill =(27,39,90,255),font=myFont)
#software price
d1.text((1070, 1120), str(fifthProjectPrice), fill =(27,39,90,255),font=myFont)
#total price
d1.text((1320, 1120),str(fifthProjectPrice), fill =(27,39,90,255),font=myFont)

#=========================================================End Software===========================================================================



#Pricing Creteria
d1.text((1210, 1363), str(totalAmount), fill =(27,39,90,255),font=myFontBold)
d1.text((1210, 1437), str(tax), fill =(27,39,90,255),font=myFontBold)#tax Price
d1.text((1210, 1505), str(amountDue), fill =(27,39,90,255),font=myFontBold)#total Price








#img.show()

img.save('./saved/'+str(name) + '.pdf');