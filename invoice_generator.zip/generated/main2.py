from PIL import Image, ImageDraw, ImageFont
 

img = Image.open('out.png')
 

d1 = ImageDraw.Draw(img)
 

myFont = ImageFont.truetype('Roboto-Light.ttf', 35)
 
#y,x

#name
d1.text((920, 300), "Deepak Mishra", fill =(27,39,90,255),font=myFont)

#number
d1.text((920, 360), "8789033735", fill =(27,39,90,255),font=myFont)


#email
d1.text((920, 410), "abc@gmail.com", fill =(27,39,90,255),font=myFont)



#address
d1.text((920, 470), "1123,street no", fill =(27,39,90,255),font=myFont)


#name
#d1.text((920, 290), "Deepak Mishra", fill =(27,39,90,255),font=myFont)
 
myFontBold = ImageFont.truetype('Roboto-Bold.ttf', 40)

#invoiceNumber
d1.text((473, 507), "103", fill =(27,39,90,255),font=myFontBold)

myFontLight = ImageFont.truetype('Roboto-Bold.ttf', 30)

#issued_date
d1.text((410, 585), "8 Dec 2021", fill =(27,39,90,255),font=myFontLight)

#=========================================================First Software===========================================================================

#software name
d1.text((220, 830), "Ekshvara Website", fill =(27,39,90,255),font=myFont)
#software Quantity
d1.text((870, 830), "1", fill =(27,39,90,255),font=myFont)
#software price
d1.text((1070, 830), "5000", fill =(27,39,90,255),font=myFont)
#total price
d1.text((1320, 830), "5000", fill =(27,39,90,255),font=myFont)

#=========================================================End Software===========================================================================



#=========================================================Second Software===========================================================================

#software name
d1.text((220, 900), "Ekshvara Website", fill =(27,39,90,255),font=myFont)
#software Quantity
d1.text((870, 900), "1", fill =(27,39,90,255),font=myFont)
#software price
d1.text((1070, 900), "5000", fill =(27,39,90,255),font=myFont)
#total price
d1.text((1320, 900), "5000", fill =(27,39,90,255),font=myFont)

#=========================================================End Software===========================================================================



#=========================================================Third Software===========================================================================

#software name
d1.text((220, 970), "Ekshvara Website", fill =(27,39,90,255),font=myFont)
#software Quantity
d1.text((870, 970), "1", fill =(27,39,90,255),font=myFont)
#software price
d1.text((1070, 970), "5000", fill =(27,39,90,255),font=myFont)
#total price
d1.text((1320, 970), "5000", fill =(27,39,90,255),font=myFont)

#=========================================================End Software===========================================================================



#=========================================================fourth Software===========================================================================

#software name
d1.text((220, 1050), "Ekshvara Website", fill =(27,39,90,255),font=myFont)
#software Quantity
d1.text((870, 1050), "1", fill =(27,39,90,255),font=myFont)
#software price
d1.text((1070, 1050), "5000", fill =(27,39,90,255),font=myFont)
#total price
d1.text((1320, 1050), "5000", fill =(27,39,90,255),font=myFont)

#=========================================================End Software===========================================================================



#=========================================================fifth Software===========================================================================

#software name
d1.text((220, 1120), "Ekshvara Website", fill =(27,39,90,255),font=myFont)
#software Quantity
d1.text((870, 1120), "1", fill =(27,39,90,255),font=myFont)
#software price
d1.text((1070, 1120), "5000", fill =(27,39,90,255),font=myFont)
#total price
d1.text((1320, 1120), "5000", fill =(27,39,90,255),font=myFont)

#=========================================================End Software===========================================================================



#Pricing Creteria
d1.text((1210, 1363), "500", fill =(27,39,90,255),font=myFontBold)
d1.text((1210, 1437), "500", fill =(27,39,90,255),font=myFontBold)#tax Price
d1.text((1210, 1505), "500", fill =(27,39,90,255),font=myFontBold)#total Price




img.show()
