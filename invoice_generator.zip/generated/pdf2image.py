from pdf2image import convert_from_path



name = convert_from_path("Quotation-1.pdf")


name[0].save("out.png","PNG")